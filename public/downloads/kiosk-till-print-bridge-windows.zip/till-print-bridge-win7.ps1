# Kiosk Till Print Bridge for Windows 7 (PowerShell + .NET - no Node.js).
# ASCII-only. Compatible with Windows PowerShell 2.0+.
# Uses TcpListener (NOT HttpListener) so no netsh URL ACL / admin is required.
# Listens on http://127.0.0.1:19500  (same API as the modern Node bridge)

$ErrorActionPreference = "Stop"
$Port = 19500
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogFile = $env:TILL_PRINT_BRIDGE_LOG
if (-not $LogFile) {
  $LogFile = Join-Path $ScriptDir "bridge.log"
}

function Write-BridgeLog([string]$Message) {
  $line = (Get-Date -Format "yyyy-MM-ddTHH:mm:ss") + " " + $Message
  try { Write-Host $line } catch { }
  try { Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue } catch { }
}

function Escape-Json([string]$s) {
  if ($null -eq $s) { return "" }
  $t = [string]$s
  $t = $t.Replace("\", "\\")
  $t = $t.Replace('"', '\"')
  $t = $t.Replace("`r", "\r")
  $t = $t.Replace("`n", "\n")
  $t = $t.Replace("`t", "\t")
  return $t
}

function Test-LikelyThermal([string]$Name, [string]$PortName) {
  $blob = ($Name + " " + $PortName).ToLower()
  if ($blob -match "fax|onenote|microsoft print to pdf|microsoft xps|adobe pdf|cutepdf|pdf creator|virtual printer") {
    return $false
  }
  if ($blob -match "caysn|xprinter|epson|tm-|star|bixolon|citizen|pos.?80|receipt|thermal|rongta|gprinter|munbyn|rp58|rp80") {
    return $true
  }
  return $false
}

function Get-PrinterRows {
  $rows = @()
  $printers = Get-WmiObject -Class Win32_Printer -ErrorAction Stop
  foreach ($p in $printers) {
    $name = [string]$p.Name
    if (-not $name) { continue }
    $portName = [string]$p.PortName
    $driver = [string]$p.DriverName
    $isDefault = [bool]$p.Default
    $likely = Test-LikelyThermal $name $portName
    $rows += New-Object PSObject -Property @{
      Name = $name
      PortName = $portName
      DriverName = $driver
      Default = $isDefault
      LikelyThermal = $likely
    }
  }
  return $rows
}

function Convert-PrintersToJson($rows) {
  $suggested = $null
  foreach ($r in $rows) {
    if ($r.LikelyThermal) { $suggested = $r.Name; break }
  }
  if (-not $suggested) {
    foreach ($r in $rows) {
      if ($r.Default) { $suggested = $r.Name; break }
    }
  }
  if (-not $suggested -and $rows.Count -eq 1) {
    $suggested = $rows[0].Name
  }

  $parts = @()
  foreach ($r in $rows) {
    $lt = "false"
    if ($r.LikelyThermal) { $lt = "true" }
    $def = "false"
    if ($r.Default) { $def = "true" }
    $uri = Escape-Json $r.PortName
    $nm = Escape-Json $r.Name
    $parts += ('{"name":"' + $nm + '","uri":"' + $uri + '","isDefault":' + $def + ',"likelyThermal":' + $lt + '}')
  }
  $arr = "[" + ([string]::Join(",", $parts)) + "]"
  $sugJson = "null"
  if ($suggested) { $sugJson = '"' + (Escape-Json $suggested) + '"' }
  return ('{"ok":true,"platform":"win32","printers":' + $arr + ',"suggested":' + $sugJson + '}')
}

function Send-WindowsRaw([string]$PrinterName, [byte[]]$Bytes) {
  # $PSScriptRoot is often $null on PowerShell 2.0 (Windows 7) — never Join-Path it.
  $base = $ScriptDir
  if (-not $base) {
    try { $base = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { }
  }
  if (-not $base) {
    $base = [string](Get-Location).Path
  }
  if (-not $base) {
    throw "Cannot resolve bridge folder to find windows-raw-print.ps1."
  }
  $helper = Join-Path $base "windows-raw-print.ps1"
  if (-not (Test-Path -LiteralPath $helper)) {
    throw ("Missing windows-raw-print.ps1 next to the bridge (" + $helper + "). Re-download the Windows 7 zip and run the installer again.")
  }
  if ([string]::IsNullOrEmpty($PrinterName)) {
    throw "PrinterName is empty."
  }
  $tempRoot = [System.IO.Path]::GetTempPath()
  if (-not $tempRoot) { $tempRoot = $base }
  $tmp = [System.IO.Path]::Combine($tempRoot, ("kiosk-escpos-" + [Guid]::NewGuid().ToString("n") + ".bin"))
  [System.IO.File]::WriteAllBytes($tmp, $Bytes)
  try {
    & $helper -PrinterName $PrinterName -FilePath $tmp
  } finally {
    if ($tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
  }
}

$script:QueueEndpoint = @{}
$script:QueueEndpointAt = @{}

function ConvertTo-DrawerEndpoint([string]$PortName) {
  $text = $PortName.Trim()
  if ($text -match '^IP_(\d{1,3}(?:\.\d{1,3}){3})(?::(\d+))?$') {
    $port = 9100
    if ($Matches[2]) { $port = [int]$Matches[2] }
    return @{ Host = $Matches[1]; Port = $port }
  }
  if ($text -match '^(\d{1,3}(?:\.\d{1,3}){3})(?::(\d+))?$') {
    $port = 9100
    if ($Matches[2]) { $port = [int]$Matches[2] }
    return @{ Host = $Matches[1]; Port = $port }
  }
  return $null
}

function Get-QueueEndpoint([string]$Name) {
  $key = $Name.Trim()
  if (-not $key) { return $null }
  $now = [DateTime]::UtcNow
  if ($script:QueueEndpointAt.ContainsKey($key)) {
    $age = $now - $script:QueueEndpointAt[$key]
    if ($age.TotalSeconds -lt 60) { return $script:QueueEndpoint[$key] }
  }
  $endpoint = $null
  foreach ($row in @(Get-PrinterRows)) {
    if ([string]$row.Name -eq $key) {
      $endpoint = ConvertTo-DrawerEndpoint ([string]$row.PortName)
      break
    }
  }
  $script:QueueEndpoint[$key] = $endpoint
  $script:QueueEndpointAt[$key] = $now
  return $endpoint
}

function Write-DrawerStatus($Stream, [string]$HostName, [int]$PortNumber) {
  try {
    $raw = Read-DrawerSwitch $HostName $PortNumber
    $pin = "false"
    if (($raw -band 1) -eq 1) { $pin = "true" }
    Write-HttpResponse $Stream 200 ("{""readable"":true,""pinHigh"":" + $pin + ",""raw"":" + $raw + "}") "application/json"
  } catch {
    Write-BridgeLog ("Drawer status unreadable: " + $_.Exception.Message)
    Write-HttpResponse $Stream 200 '{"readable":false,"reason":"timeout"}' "application/json"
  }
}

# ESC/POS GS r 2. Bit 0 of the reply is drawer-kick pin 3.
function Read-DrawerSwitch([string]$HostName, [int]$PortNumber) {
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $iar = $client.BeginConnect($HostName, $PortNumber, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne(1200, $false)
    if (-not $ok) { throw "Timed out connecting to ${HostName}:${PortNumber}" }
    $client.EndConnect($iar)
    $stream = $client.GetStream()
    $stream.ReadTimeout = 800
    $cmd = [byte[]](0x1D, 0x72, 0x02)
    $stream.Write($cmd, 0, $cmd.Length)
    $stream.Flush()
    $one = $stream.ReadByte()
    if ($one -lt 0) { throw "Printer closed the status connection" }
    return $one
  } finally {
    try { $client.Close() } catch { }
  }
}

function Send-NetworkRaw([string]$HostName, [int]$PortNumber, [byte[]]$Bytes) {
  $client = New-Object System.Net.Sockets.TcpClient
  try {
    $iar = $client.BeginConnect($HostName, $PortNumber, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne(8000, $false)
    if (-not $ok) { throw "Timed out connecting to $HostName`:$PortNumber" }
    $client.EndConnect($iar)
    $stream = $client.GetStream()
    $stream.Write($Bytes, 0, $Bytes.Length)
    $stream.Flush()
    if ($Bytes.Length -lt 128) { Start-Sleep -Milliseconds 200 }
  } finally {
    try { $client.Close() } catch { }
  }
}

function Get-HeaderValue($Headers, [string]$Name) {
  foreach ($key in $Headers.Keys) {
    if ([string]::Compare([string]$key, $Name, $true) -eq 0) {
      return [string]$Headers[$key]
    }
  }
  return ""
}

function Read-HttpRequest($Stream) {
  $ms = New-Object System.IO.MemoryStream
  $buf = New-Object byte[] 4096
  $headerText = ""
  $bodyStart = -1

  while ($true) {
    $n = $Stream.Read($buf, 0, $buf.Length)
    if ($n -le 0) { break }
    $ms.Write($buf, 0, $n)
    $headerText = [System.Text.Encoding]::ASCII.GetString($ms.ToArray())
    $idx = $headerText.IndexOf("`r`n`r`n")
    if ($idx -ge 0) {
      $bodyStart = $idx + 4
      break
    }
    if ($ms.Length -gt 65536) { throw "HTTP headers too large" }
  }

  if ($bodyStart -lt 0) { throw "Incomplete HTTP request" }

  $all = $ms.ToArray()
  $headerBytes = $bodyStart
  $headerStr = [System.Text.Encoding]::ASCII.GetString($all, 0, $headerBytes)
  $lines = $headerStr.Split([string[]]@("`r`n"), [StringSplitOptions]::None)
  if ($lines.Length -lt 1) { throw "Empty HTTP request" }

  $parts = $lines[0].Split(" ")
  if ($parts.Length -lt 2) { throw "Bad HTTP request line" }
  $method = $parts[0].ToUpper()
  $path = $parts[1]
  $q = $path.IndexOf("?")
  if ($q -ge 0) { $path = $path.Substring(0, $q) }
  $path = $path.TrimEnd("/")
  if (-not $path) { $path = "/" }

  $headers = @{}
  for ($i = 1; $i -lt $lines.Length; $i++) {
    $line = $lines[$i]
    if (-not $line) { continue }
    $colon = $line.IndexOf(":")
    if ($colon -lt 1) { continue }
    $hk = $line.Substring(0, $colon).Trim()
    $hv = $line.Substring($colon + 1).Trim()
    $headers[$hk] = $hv
  }

  $contentLength = 0
  $cl = Get-HeaderValue $headers "Content-Length"
  if ($cl) {
    try { $contentLength = [int]$cl } catch { $contentLength = 0 }
  }

  $body = New-Object byte[] 0
  if ($contentLength -gt 0) {
    $have = $all.Length - $bodyStart
    $bodyMs = New-Object System.IO.MemoryStream
    if ($have -gt 0) {
      $bodyMs.Write($all, $bodyStart, [Math]::Min($have, $contentLength))
    }
    while ($bodyMs.Length -lt $contentLength) {
      $need = $contentLength - [int]$bodyMs.Length
      $chunk = New-Object byte[] ([Math]::Min(4096, $need))
      $rn = $Stream.Read($chunk, 0, $chunk.Length)
      if ($rn -le 0) { break }
      $bodyMs.Write($chunk, 0, $rn)
    }
    $body = $bodyMs.ToArray()
  }

  return @{
    Method = $method
    Path = $path
    Headers = $headers
    Body = $body
  }
}

function Write-HttpResponse($Stream, [int]$StatusCode, [string]$Body, [string]$ContentType) {
  if (-not $ContentType) { $ContentType = "text/plain" }
  $reason = "OK"
  if ($StatusCode -eq 204) { $reason = "No Content" }
  elseif ($StatusCode -eq 400) { $reason = "Bad Request" }
  elseif ($StatusCode -eq 404) { $reason = "Not Found" }
  elseif ($StatusCode -eq 413) { $reason = "Payload Too Large" }
  elseif ($StatusCode -eq 500) { $reason = "Internal Server Error" }
  elseif ($StatusCode -eq 502) { $reason = "Bad Gateway" }

  $bodyBytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
  $sb = New-Object System.Text.StringBuilder
  [void]$sb.Append("HTTP/1.1 $StatusCode $reason`r`n")
  [void]$sb.Append("Access-Control-Allow-Origin: *`r`n")
  [void]$sb.Append("Access-Control-Allow-Methods: GET, POST, OPTIONS`r`n")
  [void]$sb.Append("Access-Control-Allow-Headers: Content-Type, X-Printer-Cups-Name, X-Printer-Host, X-Printer-Port`r`n")
  [void]$sb.Append("Access-Control-Allow-Private-Network: true`r`n")
  [void]$sb.Append("Access-Control-Max-Age: 86400`r`n")
  [void]$sb.Append("Content-Type: $ContentType`r`n")
  [void]$sb.Append("Content-Length: $($bodyBytes.Length)`r`n")
  [void]$sb.Append("Connection: close`r`n")
  [void]$sb.Append("`r`n")
  $headerBytes = [System.Text.Encoding]::ASCII.GetBytes($sb.ToString())
  $Stream.Write($headerBytes, 0, $headerBytes.Length)
  if ($bodyBytes.Length -gt 0) {
    $Stream.Write($bodyBytes, 0, $bodyBytes.Length)
  }
  $Stream.Flush()
}

function Handle-Request($Req, $Stream) {
  $method = $Req.Method
  $path = $Req.Path

  if ($method -eq "OPTIONS") {
    Write-HttpResponse $Stream 204 "" "text/plain"
    return
  }

  if ($method -eq "GET" -and ($path -eq "/health" -or $path -eq "/")) {
    $body = '{"ok":true,"platform":"win32","spooler":true,"powershell":true,"networkRaw":true,"win7":true,"printEngine":"v5-bypass-epson","drawerSwitch":"queue","port":' + $Port + '}'
    Write-HttpResponse $Stream 200 $body "application/json"
    return
  }

  if ($method -eq "GET" -and $path -eq "/printers") {
    try {
      $rows = @(Get-PrinterRows)
      $json = Convert-PrintersToJson $rows
      Write-HttpResponse $Stream 200 $json "application/json"
    } catch {
      Write-HttpResponse $Stream 500 $_.Exception.Message "text/plain"
    }
    return
  }

  if ($method -eq "POST" -and ($path -eq "/drawer/status" -or $path -eq "/drawer/status/")) {
    $netHost = Get-HeaderValue $Req.Headers "X-Printer-Host"
    $netPortRaw = Get-HeaderValue $Req.Headers "X-Printer-Port"
    $cups = Get-HeaderValue $Req.Headers "X-Printer-Cups-Name"
    if (-not $netPortRaw) { $netPortRaw = "9100" }
    $netPort = 9100
    try { $netPort = [int]$netPortRaw } catch { $netPort = 9100 }
    if ($netHost -and $netHost.Trim()) {
      Write-DrawerStatus $Stream $netHost.Trim() $netPort
      return
    }
    if ($cups -and $cups.Trim()) {
      $endpoint = Get-QueueEndpoint $cups.Trim()
      if ($endpoint) {
        Write-DrawerStatus $Stream $endpoint.Host $endpoint.Port
        return
      }
      Write-HttpResponse $Stream 200 '{"readable":false,"reason":"queue"}' "application/json"
      return
    }
    Write-HttpResponse $Stream 200 '{"readable":false,"reason":"no-printer"}' "application/json"
    return
  }

  if ($method -eq "POST" -and ($path -eq "/print" -or $path -eq "/drawer/kick")) {
    $isDrawer = ($path -eq "/drawer/kick")
    $bytes = $Req.Body
    if ($isDrawer) {
      $pulse = [byte[]](0x1b, 0x40, 0x1b, 0x70, 0x00, 0x19, 0xfa, 0x1b, 0x70, 0x01, 0x19, 0xfa, 0x0a, 0x0a)
      $bytes = New-Object byte[] 64
      [System.Buffer]::BlockCopy($pulse, 0, $bytes, 0, $pulse.Length)
    } elseif ($null -eq $bytes -or $bytes.Length -eq 0) {
      Write-HttpResponse $Stream 400 "empty body" "text/plain"
      return
    }
    if ($bytes.Length -gt 256000) {
      Write-HttpResponse $Stream 413 "payload too large" "text/plain"
      return
    }

    $netHost = Get-HeaderValue $Req.Headers "X-Printer-Host"
    $netPortRaw = Get-HeaderValue $Req.Headers "X-Printer-Port"
    $cups = Get-HeaderValue $Req.Headers "X-Printer-Cups-Name"
    if (-not $netPortRaw) { $netPortRaw = "9100" }
    $netPort = 9100
    try { $netPort = [int]$netPortRaw } catch { $netPort = 9100 }

    try {
      if ($netHost -and $netHost.Trim()) {
        Send-NetworkRaw $netHost.Trim() $netPort $bytes
        $body = '{"ok":true,"mode":"network","host":"' + (Escape-Json $netHost.Trim()) + '","port":' + $netPort + '}'
        Write-HttpResponse $Stream 200 $body "application/json"
      } elseif ($cups -and $cups.Trim()) {
        Send-WindowsRaw $cups.Trim() $bytes
        $body = '{"ok":true,"mode":"windows","name":"' + (Escape-Json $cups.Trim()) + '","platform":"win32"}'
        Write-HttpResponse $Stream 200 $body "application/json"
      } else {
        Write-HttpResponse $Stream 400 "Missing or invalid X-Printer-Cups-Name (or X-Printer-Host)" "text/plain"
      }
    } catch {
      Write-BridgeLog ("Print error: " + $_.Exception.Message)
      Write-HttpResponse $Stream 502 $_.Exception.Message "text/plain"
    }
    return
  }

  Write-HttpResponse $Stream 404 "not found" "text/plain"
}

# ---- listen (TcpListener = no URL ACL / admin needed on Win7) ----
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $Port)
try {
  $listener.Start()
} catch {
  Write-BridgeLog ("FATAL: cannot bind 127.0.0.1:$Port - " + $_.Exception.Message)
  Write-BridgeLog "Is another Kiosk bridge already running? Check bridge.log / Task Manager for powershell."
  exit 1
}

Write-BridgeLog "Till Print Bridge (Win7/TcpListener) listening on http://127.0.0.1:$Port/"
Write-BridgeLog "No Node.js required. Log: $LogFile"

while ($true) {
  $client = $null
  $stream = $null
  try {
    $client = $listener.AcceptTcpClient()
    $stream = $client.GetStream()
    $stream.ReadTimeout = 15000
    $stream.WriteTimeout = 15000
    $req = Read-HttpRequest $stream
    Handle-Request $req $stream
  } catch {
    Write-BridgeLog ("Request error: " + $_.Exception.Message)
    try {
      if ($stream) {
        Write-HttpResponse $stream 500 $_.Exception.Message "text/plain"
      }
    } catch { }
  } finally {
    try { if ($stream) { $stream.Close() } } catch { }
    try { if ($client) { $client.Close() } } catch { }
  }
}
