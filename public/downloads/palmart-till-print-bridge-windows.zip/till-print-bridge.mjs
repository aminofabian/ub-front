#!/usr/bin/env node
/**
 * Till Print Bridge — run on the cashier PC (USB / local / network thermal printer).
 *
 * Cloud-hosted Palmart cannot reach USB printers. This small local server
 * listens on 127.0.0.1:19500 and accepts raw ESC/POS from the browser.
 *
 * Platforms:
 *   macOS / Linux — CUPS (`lp` / `lpstat`)
 *   Windows 10/11 — PowerShell listener (Install-Palmart-Print-Bridge.cmd, no Node)
 *   Windows 7     — PowerShell listener (Install-Palmart-Print-Bridge-Win7.cmd)
 *   All           — Ethernet/Wi‑Fi ESC/POS on TCP port 9100 (X-Printer-Host)
 *
 * Also: POST /drawer/kick — ESC/POS cash-drawer pulse (same printer target headers).
 *
 * Usage:
 *   Windows 10/11 (recommended): run Install-Palmart-Print-Bridge.cmd once — autostarts hidden, no Node.
 *   Windows 7: Install-Palmart-Print-Bridge-Win7.cmd
 *   Dev / manual: node scripts/till-print-bridge.mjs
 *   pnpm till-print-bridge
 *
 * Optional: TILL_PRINT_BRIDGE_LOG=/path/to/bridge.log for headless file logging.
 */

import { createServer } from "node:http";
import { spawn } from "node:child_process";
import { createConnection } from "node:net";
import { appendFileSync, existsSync, readFileSync } from "node:fs";
import { unlink, writeFile } from "node:fs/promises";
import { platform as osPlatform, tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { WINDOWS_RAW_PRINT_PS1 } from "./windows-raw-print-embed.mjs";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const PRINT_ENGINE = "v5-bypass-epson";

const PORT = Number(process.env.TILL_PRINT_BRIDGE_PORT || 19500);
const HOST = "127.0.0.1";
const PLATFORM = osPlatform(); // darwin | linux | win32 | …
const IS_WIN = PLATFORM === "win32";
const IS_UNIX = PLATFORM === "darwin" || PLATFORM === "linux";
const LOG_FILE = (process.env.TILL_PRINT_BRIDGE_LOG || "").trim();

function logLine(...parts) {
  const line = parts.map((p) => String(p)).join(" ");
  try {
    console.log(line);
  } catch {
    // ignore broken stdout when detached
  }
  if (!LOG_FILE) return;
  try {
    appendFileSync(LOG_FILE, `${new Date().toISOString()} ${line}\n`, "utf8");
  } catch {
    // ignore log write failures
  }
}

const LP_BIN = ["/usr/bin/lp", "/bin/lp"].find((p) => existsSync(p));
const LPSTAT_BIN = ["/usr/bin/lpstat", "/bin/lpstat"].find((p) => existsSync(p));

/** CUPS queue names (unix). */
const UNIX_NAME_RE = /^[A-Za-z0-9._-]+$/;
/** Windows printer display names (spaces / parens allowed). */
const WIN_NAME_RE = /^[^\\/:*?"<>|]{1,200}$/;
const HOST_RE = /^[A-Za-z0-9._:-]+$/;
const MAX_BODY = 256_000;
const DEFAULT_RAW_PORT = 9100;
/** Standard ESC/POS pulse — drawer kick pin 2 then pin 5 (RJ12 wirings). */
const DRAWER_KICK = Buffer.from([
  0x1b, 0x70, 0x00, 0x19, 0xfa, // pin 2
  0x1b, 0x70, 0x01, 0x19, 0xfa, // pin 5
]);

/** Names that look like retail/thermal receipt printers (prefer when auto-picking). */
const THERMAL_HINT_RE =
  /caysn|xprinter|x-printer|epson.?tm|tm-|tm_|star.?tsp|bixolon|citizen|pos[-_ ]?80|pos80|receipt|thermal|cn\d{2,}|rp[-_]?\d|tsp\d*|tsp100|tsp143|rongta|gprinter|munbyn|rpp0|rp58|rp80|xp-?\d+|usb.?print|generic.?\/?\s*text|palmart/i;

/** Virtual / non-receipt devices to deprioritize (esp. Windows). */
const NOISE_PRINTER_RE =
  /fax|oneNote|microsoft.?print.?to.?pdf|microsoft.?xps|adobe.?pdf|send.?to.?onenote|fax.?printer|anydesk|snagit|cutepdf|doPDF|bullzip|novaPDF|pdf.?creator|virtual.?printer|fax$/i;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, X-Printer-Cups-Name, X-Printer-Host, X-Printer-Port",
  // Chrome Private Network Access: HTTPS cloud cashier → http://127.0.0.1
  "Access-Control-Allow-Private-Network": "true",
  "Access-Control-Max-Age": "86400",
};

function send(res, status, body, type = "text/plain") {
  const text = typeof body === "string" ? body : JSON.stringify(body);
  res.writeHead(status, {
    ...CORS,
    "Content-Type": type,
    "Content-Length": Buffer.byteLength(text),
  });
  res.end(text);
}

function readRequest(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (c) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function decodePsStdout(buf) {
  if (!buf || buf.length === 0) return "";
  if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
    return buf.toString("utf16le").replace(/^\uFEFF/, "");
  }
  if (buf.length >= 2 && buf[0] === 0xfe && buf[1] === 0xff) {
    return buf.swap16().toString("utf16le").replace(/^\uFEFF/, "");
  }
  if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) {
    return buf.slice(3).toString("utf8");
  }
  let nulPairs = 0;
  const sample = Math.min(buf.length, 80);
  for (let i = 1; i < sample; i += 2) {
    if (buf[i] === 0) nulPairs += 1;
  }
  if (sample >= 8 && nulPairs >= sample / 4) {
    return buf.toString("utf16le").replace(/^\uFEFF/, "");
  }
  return buf.toString("utf8").replace(/^\uFEFF/, "");
}

function runCmd(bin, args, opts = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(bin, args, {
      stdio: ["ignore", "pipe", "pipe"],
      windowsHide: true,
      ...opts,
    });
    const outChunks = [];
    const errChunks = [];
    child.stdout.on("data", (c) => {
      outChunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c));
    });
    child.stderr.on("data", (c) => {
      errChunks.push(Buffer.isBuffer(c) ? c : Buffer.from(c));
    });
    child.on("error", reject);
    child.on("close", (code) => {
      const stdout = decodePsStdout(Buffer.concat(outChunks));
      const stderr = decodePsStdout(Buffer.concat(errChunks));
      if (code === 0) resolve(stdout);
      else reject(new Error(stderr.trim() || `${bin} exited ${code}`));
    });
  });
}

function isValidPrinterName(name) {
  if (!name) return false;
  if (IS_WIN) return WIN_NAME_RE.test(name);
  return UNIX_NAME_RE.test(name);
}

function isNoisePrinter(name, uri = "") {
  return NOISE_PRINTER_RE.test(name) || NOISE_PRINTER_RE.test(uri);
}

function isLikelyThermal(name, uri = "") {
  if (isNoisePrinter(name, uri)) return false;
  return THERMAL_HINT_RE.test(name) || THERMAL_HINT_RE.test(uri);
}

function rankAndSuggest(printers, defaultName) {
  printers.sort((a, b) => {
    if (a.likelyThermal !== b.likelyThermal) return a.likelyThermal ? -1 : 1;
    const aNoise = isNoisePrinter(a.name, a.uri);
    const bNoise = isNoisePrinter(b.name, b.uri);
    if (aNoise !== bNoise) return aNoise ? 1 : -1;
    if (a.isDefault !== b.isDefault) return a.isDefault ? -1 : 1;
    return a.name.localeCompare(b.name);
  });

  const suggested =
    printers.find((p) => p.likelyThermal)?.name ??
    printers.find((p) => !isNoisePrinter(p.name, p.uri) && p.isDefault)?.name ??
    printers.find((p) => !isNoisePrinter(p.name, p.uri))?.name ??
    (printers.length === 1 ? printers[0].name : null);

  return { printers, suggested, defaultName };
}

/**
 * List CUPS queues from `lpstat -v` / `lpstat -d` (macOS / Linux).
 */
async function listCupsPrinters() {
  if (!LPSTAT_BIN) {
    throw new Error(
      "CUPS lpstat not found. On Linux install cups (`sudo apt install cups`). On macOS it is built-in.",
    );
  }
  const [devicesOut, defaultOut] = await Promise.all([
    runCmd(LPSTAT_BIN, ["-v"]),
    runCmd(LPSTAT_BIN, ["-d"]).catch(() => ""),
  ]);

  const defaultMatch = /system default destination:\s*(\S+)/i.exec(defaultOut);
  const defaultName = defaultMatch?.[1]?.trim() || null;

  const printers = [];
  for (const line of devicesOut.split("\n")) {
    const m = /^device for\s+(\S+):\s*(.*)$/i.exec(line.trim());
    if (!m) continue;
    const name = m[1];
    if (!UNIX_NAME_RE.test(name)) continue;
    const uri = (m[2] || "").trim();
    printers.push({
      name,
      uri,
      isDefault: Boolean(defaultName && name === defaultName),
      likelyThermal: isLikelyThermal(name, uri),
    });
  }

  return rankAndSuggest(printers, defaultName);
}

function printersFromBridgeJson(parsed) {
  const rows = Array.isArray(parsed?.printers)
    ? parsed.printers
    : Array.isArray(parsed)
      ? parsed
      : parsed
        ? [parsed]
        : [];
  const printers = [];
  let defaultName =
    typeof parsed?.defaultName === "string" ? parsed.defaultName : null;
  for (const row of rows) {
    const name = String(row?.name ?? row?.Name ?? "").trim();
    if (!name || !WIN_NAME_RE.test(name)) continue;
    const uri = String(
      row?.uri ?? row?.PortName ?? row?.DriverName ?? "",
    ).trim();
    const isDefault = Boolean(row?.isDefault ?? row?.Default);
    if (isDefault) defaultName = name;
    printers.push({
      name,
      uri,
      isDefault,
      likelyThermal:
        typeof row?.likelyThermal === "boolean"
          ? row.likelyThermal
          : isLikelyThermal(name, uri),
    });
  }
  return rankAndSuggest(printers, defaultName);
}

/**
 * List Windows printers via PowerShell.
 * Prefer the Win10 helper (USB auto-queue + WMI). Fall back to WMI JSON.
 */
async function listWindowsPrinters() {
  const helper = join(SCRIPT_DIR, "till-print-bridge-windows.ps1");
  if (existsSync(helper)) {
    try {
      const out = await runCmd("powershell.exe", [
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        helper,
        "-ListOnly",
      ]);
      const trimmed = out.trim();
      if (!trimmed) return rankAndSuggest([], null);
      return printersFromBridgeJson(JSON.parse(trimmed));
    } catch (e) {
      logLine(
        "Windows ListOnly helper failed, falling back to WMI:",
        e instanceof Error ? e.message : e,
      );
    }
  }

  const ps = `
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
$OutputEncoding = [Console]::OutputEncoding
$rows = @()
try {
  $rows = @(Get-WmiObject -Class Win32_Printer -ErrorAction Stop)
} catch {
  try { $rows = @(Get-Printer -ErrorAction Stop) } catch { $rows = @() }
}
$parts = @()
$suggested = $null
$defaultName = $null
function Esc([string]$s) {
  if ($null -eq $s) { return '' }
  return $s.Replace('\\','\\\\').Replace('"','\\"')
}
foreach ($p in $rows) {
  $name = [string]$p.Name
  if (-not $name) { continue }
  $port = [string]$p.PortName
  $def = $false
  try { $def = [bool]$p.Default } catch { }
  if ($def) { $defaultName = $name }
  $blob = ($name + ' ' + $port).ToLower()
  $lt = $blob -match 'caysn|xprinter|epson|pos.?80|thermal|receipt|xp-?\\d+|usb.?print|generic.?/?\\s*text|usb\\d+|com\\d+'
  $noise = $blob -match 'fax|onenote|print to pdf|xps'
  if ($lt -and -not $suggested) { $suggested = $name }
  $defJson = 'false'
  if ($def) { $defJson = 'true' }
  $ltJson = 'false'
  if ($lt -and -not $noise) { $ltJson = 'true' }
  $parts += ('{"name":"' + (Esc $name) + '","uri":"' + (Esc $port) + '","isDefault":' + $defJson + ',"likelyThermal":' + $ltJson + '}')
}
$arr = '[' + ([string]::Join(',', $parts)) + ']'
$sug = 'null'
if ($suggested) { $sug = '"' + (Esc $suggested) + '"' }
$defj = 'null'
if ($defaultName) { $defj = '"' + (Esc $defaultName) + '"' }
Write-Output ('{"ok":true,"platform":"win32","printers":' + $arr + ',"suggested":' + $sug + ',"defaultName":' + $defj + '}')
`.trim();

  let out;
  try {
    out = await runCmd("powershell.exe", [
      "-NoProfile",
      "-NonInteractive",
      "-ExecutionPolicy",
      "Bypass",
      "-Command",
      ps,
    ]);
  } catch (e) {
    throw new Error(
      e instanceof Error
        ? e.message
        : "PowerShell could not list printers. Is the Print Spooler running?",
    );
  }

  const trimmed = out.trim();
  if (!trimmed) return rankAndSuggest([], null);

  try {
    return printersFromBridgeJson(JSON.parse(trimmed));
  } catch {
    throw new Error(
      "Could not parse Windows printer list from PowerShell. Try restarting the Print Spooler service.",
    );
  }
}

async function listPrinters() {
  if (IS_WIN) return listWindowsPrinters();
  if (IS_UNIX) return listCupsPrinters();
  throw new Error(`Unsupported platform: ${PLATFORM}`);
}

function sendCups(name, data) {
  return new Promise((resolve, reject) => {
    if (!LP_BIN) {
      reject(
        new Error(
          "CUPS lp not found. On Linux install cups. On macOS it is built-in.",
        ),
      );
      return;
    }
    const file = join(tmpdir(), `palmart-escpos-${process.pid}-${Date.now()}.bin`);
    writeFile(file, data)
      .then(() => {
        const child = spawn(
          LP_BIN,
          [
            "-d",
            name,
            "-o",
            "raw",
            "-o",
            "document-format=application/vnd.cups-raw",
            file,
          ],
          { stdio: ["ignore", "pipe", "pipe"] },
        );
        let stderr = "";
        child.stderr.on("data", (c) => {
          stderr += c.toString();
        });
        child.on("error", reject);
        child.on("close", (code) => {
          unlink(file).catch(() => undefined);
          if (code === 0) resolve();
          else
            reject(
              new Error(
                stderr.trim() ||
                  `lp exited ${code} for queue "${name}" (check lpstat -v)`,
              ),
            );
        });
      })
      .catch(reject);
  });
}

/**
 * Always materialize the v5 print script (embedded in this bridge) so an old
 * install folder missing windows-raw-print.ps1 still gets the fixed engine.
 */
async function materializeWindowsRawPrintPs1() {
  const beside = join(SCRIPT_DIR, "windows-raw-print.ps1");
  let source = WINDOWS_RAW_PRINT_PS1;
  try {
    if (existsSync(beside)) {
      const disk = readFileSync(beside, "utf8");
      if (disk.includes("v5-bypass-epson")) source = disk;
    }
  } catch {
    // use embedded
  }
  const helper = join(
    tmpdir(),
    `palmart-windows-raw-print-${PRINT_ENGINE}.ps1`,
  );
  await writeFile(helper, source, "utf8");
  return helper;
}

/**
 * Send RAW bytes to a Windows printer (port/share first; spooler skipped for Epson).
 */
async function sendWindowsRaw(name, data) {
  const printer = String(name || "").trim();
  if (!printer) {
    throw new Error("Printer name is empty.");
  }
  const file = join(
    tmpdir(),
    `palmart-escpos-${process.pid}-${Date.now()}.bin`,
  );
  await writeFile(file, data);
  const helper = await materializeWindowsRawPrintPs1();
  if (!helper || !existsSync(helper)) {
    throw new Error("Failed to prepare windows-raw-print.ps1.");
  }
  if (!existsSync(file)) {
    throw new Error("Failed to write temp print file.");
  }

  try {
    await runCmd("powershell.exe", [
      "-NoProfile",
      "-NonInteractive",
      "-ExecutionPolicy",
      "Bypass",
      "-File",
      helper,
      "-PrinterName",
      printer,
      "-FilePath",
      file,
    ]);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    throw new Error(
      msg.trim() || `Windows raw print failed for "${printer}"`,
    );
  } finally {
    unlink(file).catch(() => undefined);
  }
}

function sendNetworkRaw(host, port, data) {
  return new Promise((resolve, reject) => {
    const socket = createConnection({ host, port }, () => {
      socket.write(data, (err) => {
        if (err) {
          socket.destroy();
          reject(err);
          return;
        }
        socket.end(() => resolve());
      });
    });
    socket.setTimeout(8_000, () => {
      socket.destroy();
      reject(new Error(`Timed out connecting to ${host}:${port}`));
    });
    socket.on("error", reject);
  });
}

async function sendRaw(name, data) {
  if (IS_WIN) return sendWindowsRaw(name, data);
  if (IS_UNIX) return sendCups(name, data);
  throw new Error(`Unsupported platform: ${PLATFORM}`);
}

function parsePort(raw) {
  const n = Number(raw);
  if (!Number.isFinite(n) || n < 1 || n > 65535) return DEFAULT_RAW_PORT;
  return Math.trunc(n);
}

const server = createServer(async (req, res) => {
  if (req.method === "OPTIONS") {
    send(res, 204, "");
    return;
  }

  const url = req.url?.split("?")[0] ?? "/";

  if (req.method === "GET" && (url === "/health" || url === "/health/")) {
    send(
      res,
      200,
      {
        ok: true,
        platform: PLATFORM,
        cups: IS_UNIX ? Boolean(LP_BIN) : false,
        lpstat: IS_UNIX ? Boolean(LPSTAT_BIN) : false,
        spooler: IS_WIN,
        powershell: IS_WIN,
        networkRaw: true,
        printEngine: IS_WIN ? PRINT_ENGINE : "cups-or-network",
        port: PORT,
      },
      "application/json",
    );
    return;
  }

  if (req.method === "GET" && (url === "/printers" || url === "/printers/")) {
    try {
      const listed = await listPrinters();
      send(
        res,
        200,
        { ok: true, platform: PLATFORM, ...listed },
        "application/json",
      );
    } catch (e) {
      send(res, 502, e instanceof Error ? e.message : String(e));
    }
    return;
  }

  if (
    req.method === "POST" &&
    (url === "/print" ||
      url === "/print/" ||
      url === "/drawer/kick" ||
      url === "/drawer/kick/")
  ) {
    const isDrawerKick = url === "/drawer/kick" || url === "/drawer/kick/";
    const netHost = req.headers["x-printer-host"]?.trim() || "";
    const netPort = parsePort(req.headers["x-printer-port"]);
    const cups = req.headers["x-printer-cups-name"]?.trim() || "";

    const body = isDrawerKick ? DRAWER_KICK : await readRequest(req);
    if (!isDrawerKick && body.length === 0) {
      send(res, 400, "empty body");
      return;
    }
    if (!isDrawerKick && body.length > MAX_BODY) {
      send(res, 413, "payload too large");
      return;
    }

    try {
      if (netHost) {
        if (!HOST_RE.test(netHost)) {
          send(res, 400, "Invalid X-Printer-Host");
          return;
        }
        await sendNetworkRaw(netHost, netPort, body);
        send(
          res,
          200,
          JSON.stringify({
            ok: true,
            mode: "network",
            host: netHost,
            port: netPort,
            ...(isDrawerKick ? { drawer: true } : {}),
          }),
          "application/json",
        );
        return;
      }

      if (!cups || !isValidPrinterName(cups)) {
        send(
          res,
          400,
          "Missing or invalid X-Printer-Cups-Name (set under Branches → Receipt details, or Detect printers)",
        );
        return;
      }

      await sendRaw(cups, body);
      send(
        res,
        200,
        JSON.stringify({
          ok: true,
          mode: IS_WIN ? "windows" : "cups",
          name: cups,
          platform: PLATFORM,
          ...(isDrawerKick ? { drawer: true } : {}),
        }),
        "application/json",
      );
    } catch (e) {
      send(res, 502, e instanceof Error ? e.message : String(e));
    }
    return;
  }

  send(res, 404, "not found");
});

server.on("error", (err) => {
  if (err && err.code === "EADDRINUSE") {
    logLine(
      `Till Print Bridge already listening on http://${HOST}:${PORT} — exiting cleanly.`,
    );
    process.exit(0);
  }
  logLine("Till Print Bridge failed to start:", err instanceof Error ? err.message : err);
  process.exit(1);
});

server.listen(PORT, HOST, () => {
  logLine(`Till Print Bridge listening on http://${HOST}:${PORT}`);
  logLine(`Platform: ${PLATFORM}`);
  if (IS_UNIX) {
    logLine(`CUPS lp: ${LP_BIN ?? "NOT FOUND"}`);
    logLine(`CUPS lpstat: ${LPSTAT_BIN ?? "NOT FOUND"}`);
  } else if (IS_WIN) {
    logLine("Windows: PowerShell WMI / USB auto-queue / WritePrinter (RAW)");
  }
  logLine("Network ESC/POS: X-Printer-Host (+ optional X-Printer-Port, default 9100)");
  logLine("Cash drawer: POST /drawer/kick (same printer headers as /print)");
  if (LOG_FILE) {
    logLine(`Logging to ${LOG_FILE}`);
  } else if (IS_WIN) {
    logLine("Installed via Windows installer? It runs hidden at logon — no console needed.");
  } else {
    logLine("Leave this process running while using cloud cashier (or use the OS installer / autostart).");
  }
});
